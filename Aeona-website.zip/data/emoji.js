module.exports = {
  x: ":x:",
  fail: ":x: ",
  check: ":white_check_mark: ",
  success: "<:success:956753542658535454> ",
  cash: "₪",
};
