module.exports = {
  prefix: "+",
  owners: ["794921502230577182", "394320584089010179"],
};
