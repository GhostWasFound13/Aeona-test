module.exports = {
  getMove: require("./getMove"),
  Options: require("./Options"),
  getResult: require("./getResult"),
  getContent: require("./getContent"),
};
