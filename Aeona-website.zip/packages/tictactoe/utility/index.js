module.exports = {
  getChoice: require("./getChoice"),
  getComponents: require("./getComponent"),
  getDescription: require("./getDescription"),
  getEmoji: require("./getEmoji"),
  getNumber: require("./getNumber"),
  getWinner: require("./getWinner"),
  getApproval: require("./getApproval"),
};
